
import './App.css';
import HomePage from './app/pages/HomePage';

function App() {
  return (
    <HomePage />
  );
}

export default App;
